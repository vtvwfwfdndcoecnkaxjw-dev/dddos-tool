"""
EVENTOS DE MEMBROS
Manipula entrada, saída e atualizações de membros
"""

import discord
from discord.ext import commands
from datetime import datetime
from typing import Optional

from core.config import config
from core.database import db
from core.logger import logger

from systems.roles import SistemaCargos
from systems.invites import SistemaConvites

# Inicializar sistemas
sistema_cargos = None
sistema_convites = None

async def get_log_channel(guild: discord.Guild, tipo: str) -> Optional[discord.TextChannel]:
    """Obtém canal de log pelo tipo"""
    canal_id = db.get_channel_config(tipo)
    
    # Tentar por ID
    if canal_id:
        canal = guild.get_channel(canal_id)
        if canal:
            return canal
    
    # Tentar por nome
    canal_nome = config.LOGS_CONFIG.get(tipo)
    if canal_nome:
        canal = discord.utils.get(guild.text_channels, name=canal_nome)
        if canal:
            return canal
        
        # Buscar por parte do nome
        for channel in guild.text_channels:
            if canal_nome.split('・')[-1] in channel.name:
                return channel
    
    return None

async def log_entrada(member: discord.Member):
    """Registra entrada de membro"""
    canal = await get_log_channel(member.guild, "entrada_saida")
    if not canal:
        return
    
    embed = discord.Embed(
        title="👤 MEMBRO ENTROU",
        description=f"**{member.name}** entrou no servidor",
        color=0x00ff00,
        timestamp=datetime.now()
    )
    embed.add_field(name="🆔 ID", value=member.id, inline=True)
    embed.add_field(name="📅 Conta Criada", value=member.created_at.strftime("%d/%m/%Y"), inline=True)
    
    if member.avatar:
        embed.set_thumbnail(url=member.avatar.url)
    
    await canal.send(embed=embed)

async def log_saida(member: discord.Member):
    """Registra saída de membro"""
    canal = await get_log_channel(member.guild, "entrada_saida")
    if not canal:
        return
    
    embed = discord.Embed(
        title="🚪 MEMBRO SAIU",
        description=f"**{member.name}** saiu do servidor",
        color=0xff0000,
        timestamp=datetime.now()
    )
    await canal.send(embed=embed)

async def log_moderacao(acao: str, autor: discord.Member, alvo: discord.Member, 
                       motivo: Optional[str] = None, duracao: Optional[str] = None):
    """Registra ação de moderação"""
    canal = await get_log_channel(autor.guild, "moderacao")
    if not canal:
        return
    
    embed = discord.Embed(
        title=f"🛡️ {acao}",
        color=0xff9900,
        timestamp=datetime.now()
    )
    embed.add_field(name="👮 Moderador", value=autor.mention, inline=True)
    embed.add_field(name="🎯 Alvo", value=alvo.mention, inline=True)
    
    if duracao:
        embed.add_field(name="⏰ Duração", value=duracao, inline=True)
    
    if motivo:
        embed.add_field(name="📝 Motivo", value=motivo, inline=False)
    
    await canal.send(embed=embed)

async def log_advertencia(member: discord.Member, moderador: discord.Member, 
                         motivo: str, advertencia_num: int):
    """Registra advertência"""
    canal = await get_log_channel(member.guild, "advertencias")
    if not canal:
        return
    
    embed = discord.Embed(
        title=f"⚠️ ADVERTÊNCIA #{advertencia_num}",
        color=0xffff00,
        timestamp=datetime.now()
    )
    embed.add_field(name="👤 Membro", value=member.mention, inline=True)
    embed.add_field(name="👮 Moderador", value=moderador.mention, inline=True)
    embed.add_field(name="📝 Motivo", value=motivo, inline=False)
    embed.add_field(name="🚨 Status", value=f"{advertencia_num}/{config.MAX_WARNINGS} advertências", inline=True)
    
    if advertencia_num >= config.MAX_WARNINGS:
        embed.add_field(name="🔨 Ação", value="**BAN AUTOMÁTICO**", inline=True)
    
    await canal.send(embed=embed)

async def log_pontuacao(member: discord.Member, acao: str, pontos: int, total: int):
    """Registra atualização de pontuação"""
    canal = await get_log_channel(member.guild, "pontuacao")
    if not canal:
        return
    
    embed = discord.Embed(
        title="📊 PONTUAÇÃO ATUALIZADA",
        color=0x00ff00,
        timestamp=datetime.now()
    )
    embed.add_field(name="👤 Membro", value=member.mention, inline=True)
    embed.add_field(name="🎯 Ação", value=acao, inline=True)
    embed.add_field(name="⭐ Pontos", value=f"+{pontos}", inline=True)
    embed.add_field(name="🏆 Total", value=total, inline=True)
    
    if member.avatar:
        embed.set_thumbnail(url=member.avatar.url)
    
    await canal.send(embed=embed)

async def log_conquista(member: discord.Member, conquista: str, descricao: str):
    """Registra conquista"""
    canal = await get_log_channel(member.guild, "conquistas")
    if not canal:
        return
    
    embed = discord.Embed(
        title="🏆 NOVA CONQUISTA!",
        color=0xffd700,
        timestamp=datetime.now()
    )
    embed.add_field(name="👤 Membro", value=member.mention, inline=True)
    embed.add_field(name="🎯 Conquista", value=conquista, inline=True)
    embed.add_field(name="📝 Descrição", value=descricao, inline=False)
    
    if member.avatar:
        embed.set_thumbnail(url=member.avatar.url)
    
    await canal.send(embed=embed)

async def setup(bot: commands.Bot):
    """Setup dos eventos de membros"""
    global sistema_cargos, sistema_convites
    
    sistema_cargos = SistemaCargos(bot)
    sistema_convites = SistemaConvites(bot)
    
    @bot.event
    async def on_member_join(member: discord.Member):
        """Evento quando um membro entra no servidor"""
        # Log de entrada
        await log_entrada(member)
        
        # Sistema de segurança - verificar bots
        security_system = bot.systems.get('security')
        if security_system and member.bot:
            await security_system.verificar_bot_entrada(member)
        
        # Sistema de cargos
        if sistema_cargos:
            await sistema_cargos.atribuir_cargo_membro_automatico(member)
            await sistema_cargos.atualizar_nick_automatico(member)
        
        # Sistema de convites
        if sistema_convites:
            await sistema_convites.processar_convite(member)
        
        logger.info(f"👤 {member.name} entrou no servidor {member.guild.name}")
    
    @bot.event
    async def on_member_remove(member: discord.Member):
        """Evento quando um membro sai do servidor"""
        # Log de saída
        await log_saida(member)
        
        # Sistema de detecção
        detection_system = bot.systems.get('detection')
        if detection_system and not detection_system.modo_emergencia:
            async for entry in member.guild.audit_logs(limit=5, action=discord.AuditLogAction.kick):
                if entry.target.id == member.id:
                    autor = entry.user
                    
                    # Verificar se é bot da whitelist
                    security_system = bot.systems.get('security')
                    if security_system and autor.bot and autor.id in security_system.whitelist_bots:
                        return
                    
                    # Detectar padrão de mass kick
                    if detection_system:
                        await detection_system.detectar_ataque_em_andamento(
                            member.guild, autor, "kick"
                        )
                    break
        
        logger.info(f"🚪 {member.name} saiu do servidor {member.guild.name}")
    
    @bot.event
    async def on_member_ban(guild: discord.Guild, user: discord.User):
        """Evento quando um membro é banido"""
        # Sistema de detecção
        detection_system = bot.systems.get('detection')
        if detection_system and not detection_system.modo_emergencia:
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.ban):
                if entry.target.id == user.id:
                    autor = entry.user
                    
                    # Verificar se é bot da whitelist
                    security_system = bot.systems.get('security')
                    if security_system and autor.bot and autor.id in security_system.whitelist_bots:
                        return
                    
                    # Detectar padrão de mass ban
                    if detection_system:
                        await detection_system.detectar_ataque_em_andamento(
                            guild, autor, "ban"
                        )
                    break
        
        logger.info(f"🔨 {user.name} foi banido do servidor {guild.name}")
    
    @bot.event
    async def on_member_update(before: discord.Member, after: discord.Member):
        """Evento quando um membro é atualizado"""
        # Verificar se os cargos foram alterados
        if before.roles != after.roles:
            # Log de alteração de cargos
            canal = await get_log_channel(after.guild, "cargos")
            if canal:
                embed = discord.Embed(
                    title="⭐ CARGO ALTERADO",
                    description=f"**{after.name}** teve seus cargos atualizados",
                    color=0x0099ff,
                    timestamp=datetime.now()
                )
                
                # Verificar cargos adicionados
                cargos_adicionados = [role for role in after.roles if role not in before.roles]
                if cargos_adicionados:
                    embed.add_field(
                        name="➕ Adicionados",
                        value=", ".join([role.mention for role in cargos_adicionados]),
                        inline=False
                    )
                
                # Verificar cargos removidos
                cargos_removidos = [role for role in before.roles if role not in after.roles]
                if cargos_removidos:
                    embed.add_field(
                        name="➖ Removidos",
                        value=", ".join([role.mention for role in cargos_removidos]),
                        inline=False
                    )
                
                await canal.send(embed=embed)
            
            # Atualizar nick automático
            if sistema_cargos:
                await sistema_cargos.atualizar_nick_automatico(after)
    
    @bot.event
    async def on_user_update(before: discord.User, after: discord.User):
        """Evento quando um usuário é atualizado globalmente"""
        # Registrar mudanças de nome/avatar em todos os servidores
        if before.name != after.name or before.avatar != after.avatar:
            logger.info(f"👤 Usuário atualizado: {before.name} -> {after.name}")
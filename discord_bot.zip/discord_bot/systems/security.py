"""
SISTEMA DE SEGURANÇA MULTIFACETADO
Proteção avançada contra raids, nukes e abusos
"""

import discord
import asyncio
import string
import random
from datetime import datetime, timedelta
from typing import Dict, Set, Optional, List

from core.config import config
from core.database import db
from core.logger import logger

class SistemaSegurancaMultifacetado:
    """Sistema de segurança completo com whitelist e quarentena"""
    
    def __init__(self, bot):
        self.bot = bot
        self.whitelist_bots: Set[int] = set()
        self.quarentena_usuarios: Dict[str, dict] = {}
        self.rate_limit_actions: Dict[str, List[dict]] = {}
        self.cargo_quarentena: Optional[discord.Role] = None
        self.contador_acoes_bot: Dict[str, dict] = {}
        self.auto_destruicao_ativa = False
        
        # Token para whitelist
        self.whitelist_token: Optional[str] = None
        self.gerar_token_whitelist()
        
        # Carregar dados
        self.carregar_dados_seguranca()
        
        logger.info("🛡️ Sistema de Segurança Multifacetado Inicializado!")
    
    async def setup(self):
        """Inicialização assíncrona"""
        self.bot.loop.create_task(self.loop_auto_liberacao())
        self.bot.loop.create_task(self.monitorar_uso_bot())
        logger.info("🛡️ Sistema de Segurança Multifacetado Ativado!")
    
    def gerar_token_whitelist(self):
        """Gera token para whitelist de bots"""
        if not self.whitelist_token:
            chars = string.ascii_letters + string.digits
            self.whitelist_token = ''.join(random.choice(chars) for _ in range(32))
            db.add_whitelist_token(self.whitelist_token)
    
    def carregar_dados_seguranca(self):
        """Carrega dados de segurança do banco"""
        # Carregar whitelist
        if 'ssm_whitelist' in db.data['config']:
            self.whitelist_bots = set(db.data['config']['ssm_whitelist'])
        
        # Carregar quarentena
        if 'ssm_quarentena' in db.data['config']:
            self.quarentena_usuarios = db.data['config']['ssm_quarentena']
        
        # Carregar rate limit
        if 'ssm_rate_limit' in db.data['config']:
            self.rate_limit_actions = db.data['config']['ssm_rate_limit']
        
        # Carregar token
        token = db.get_whitelist_token()
        if token:
            self.whitelist_token = token
    
    def salvar_dados_seguranca(self):
        """Salva dados de segurança no banco"""
        db.data['config']['ssm_whitelist'] = list(self.whitelist_bots)
        db.data['config']['ssm_quarentena'] = self.quarentena_usuarios
        db.data['config']['ssm_rate_limit'] = self.rate_limit_actions
        db.save()
    
    async def criar_cargo_quarentena(self, guild: discord.Guild) -> discord.Role:
        """Cria o cargo de quarentena se não existir"""
        cargo = discord.utils.get(guild.roles, name="[SSM - QUARENTENA]")
        
        if not cargo:
            cargo = await guild.create_role(
                name="[SSM - QUARENTENA]",
                color=discord.Color.dark_red(),
                reason="Cargo de quarentena para o Sistema de Segurança"
            )
            
            # Negar todas as permissões
            for channel in guild.channels:
                try:
                    await channel.set_permissions(cargo, 
                        read_messages=False,
                        send_messages=False,
                        connect=False,
                        speak=False,
                        use_application_commands=False,
                        create_instant_invite=False,
                        add_reactions=False
                    )
                except:
                    continue
        
        self.cargo_quarentena = cargo
        return cargo
    
    async def colocar_quarentena(self, member: discord.Member, duracao_minutos: int = 60, 
                                motivo: str = "Comportamento suspeito") -> bool:
        """Coloca um usuário em quarentena"""
        # Ignorar bots da whitelist
        if member.bot and member.id in self.whitelist_bots:
            return False
        
        cargo = await self.criar_cargo_quarentena(member.guild)
        
        # Remover todos os cargos
        cargos_anteriores = [role for role in member.roles if role != member.guild.default_role]
        
        try:
            await member.remove_roles(*cargos_anteriores)
            await member.add_roles(cargo)
        except Exception as e:
            logger.error(f"Erro ao aplicar quarentena: {e}")
            return False
        
        # Registrar na quarentena
        tempo_fim = datetime.now() + timedelta(minutes=duracao_minutos)
        
        db.add_quarantine(
            member.id,
            tempo_fim.isoformat(),
            motivo,
            [role.id for role in cargos_anteriores]
        )
        
        # Log
        from events.member_events import log_moderacao
        await log_moderacao("QUARENTENA", self.bot.user, member, 
                          f"{motivo} | Duração: {duracao_minutos}min")
        
        return True
    
    async def remover_quarentena(self, member: discord.Member) -> bool:
        """Remove um usuário da quarentena"""
        dados = db.get_quarantine(member.id)
        
        if not dados:
            return False
        
        cargo = await self.criar_cargo_quarentena(member.guild)
        
        try:
            await member.remove_roles(cargo)
            
            # Restaurar cargos anteriores
            cargos_restaurar = []
            for role_id in dados.get("cargos_anteriores", []):
                role = member.guild.get_role(role_id)
                if role:
                    cargos_restaurar.append(role)
            
            if cargos_restaurar:
                await member.add_roles(*cargos_restaurar)
            
            db.remove_quarantine(member.id)
            
            # Log
            from events.member_events import log_moderacao
            await log_moderacao("QUARENTENA REMOVIDA", self.bot.user, member, 
                              "Quarentena expirada/removida")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao remover quarentena: {e}")
            return False
    
    async def loop_auto_liberacao(self):
        """Loop para liberação automática da quarentena"""
        await self.bot.wait_until_ready()
        
        while not self.bot.is_closed():
            try:
                agora = datetime.now()
                usuarios_remover = []
                
                for user_id, dados in db.data.get('quarentena', {}).items():
                    tempo_fim = datetime.fromisoformat(dados["tempo_fim"])
                    if agora >= tempo_fim:
                        usuarios_remover.append(int(user_id))
                
                for user_id in usuarios_remover:
                    for guild in self.bot.guilds:
                        member = guild.get_member(user_id)
                        if member:
                            await self.remover_quarentena(member)
                            break
                
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"Erro no loop de liberação: {e}")
                await asyncio.sleep(60)
    
    async def verificar_bot_entrada(self, member: discord.Member) -> bool:
        """Verifica se um bot que entrou está na whitelist"""
        if not member.bot:
            return True
        
        # Bots na whitelist são totalmente ignorados
        if member.id in self.whitelist_bots:
            return True
        
        # Bots não autorizados apenas são registrados
        from events.member_events import log_moderacao
        await log_moderacao("BOT NÃO AUTORIZADO", self.bot.user, member, 
                          "Bot não autorizado entrou no servidor (apenas monitorado)")
        return True
    
    async def detectar_nuke(self, guild: discord.Guild, author: discord.Member, 
                           acao: str) -> bool:
        """Detecta ataques de nuke/flood"""
        # Ignorar ações do próprio bot E bots da whitelist
        if author.id == self.bot.user.id or (author.bot and author.id in self.whitelist_bots):
            return False
        
        user_id = str(author.id)
        
        if user_id not in self.rate_limit_actions:
            self.rate_limit_actions[user_id] = []
        
        # Registrar ação
        self.rate_limit_actions[user_id].append({
            "acao": acao,
            "timestamp": datetime.now().isoformat()
        })
        
        # Manter apenas ações dos últimos 5 segundos
        agora = datetime.now()
        self.rate_limit_actions[user_id] = [
            a for a in self.rate_limit_actions[user_id]
            if (agora - datetime.fromisoformat(a["timestamp"])).total_seconds() <= 5
        ]
        
        # Verificar limites
        if len(self.rate_limit_actions[user_id]) >= 5:  # 5 ações em 5 segundos
            await self.colocar_quarentena(author, 120, "Detectado padrão de nuke/flood")
            await self.reverter_acoes_destrutivas(guild, author)
            return True
        
        return False
    
    async def reverter_acoes_destrutivas(self, guild: discord.Guild, author: discord.Member):
        """Reverte ações destrutivas em lote"""
        try:
            # Ignorar ações de bots da whitelist
            if author.bot and author.id in self.whitelist_bots:
                return
            
            # Reverter canais criados recentemente
            async for entry in guild.audit_logs(limit=10, action=discord.AuditLogAction.channel_create):
                if entry.user.id == author.id:
                    try:
                        await entry.target.delete()
                    except:
                        continue
            
            # Reverter cargos criados recentemente
            async for entry in guild.audit_logs(limit=10, action=discord.AuditLogAction.role_create):
                if entry.user.id == author.id:
                    try:
                        await entry.target.delete()
                    except:
                        continue
        except Exception as e:
            logger.error(f"Erro ao reverter ações: {e}")
    
    async def detectar_flood_mensagens(self, message: discord.Message) -> bool:
        """Detecta flood de mensagens SEM auto-delete"""
        # Ignorar bots da whitelist
        if message.author.bot and message.author.id in self.whitelist_bots:
            return False
        
        user_id = str(message.author.id)
        
        if user_id not in self.rate_limit_actions:
            self.rate_limit_actions[user_id] = []
        
        # Registrar mensagem
        self.rate_limit_actions[user_id].append({
            "acao": "message_send",
            "timestamp": datetime.now().isoformat(),
            "channel_id": message.channel.id
        })
        
        # Manter apenas ações dos últimos 10 segundos
        agora = datetime.now()
        self.rate_limit_actions[user_id] = [
            a for a in self.rate_limit_actions[user_id]
            if (agora - datetime.fromisoformat(a["timestamp"])).total_seconds() <= 10
        ]
        
        # Verificar mensagens no mesmo canal
        mensagens_no_canal = [
            a for a in self.rate_limit_actions[user_id] 
            if a.get('channel_id') == message.channel.id and a['acao'] == 'message_send'
        ]
        
        # Apenas avisar, não deletar
        if len(mensagens_no_canal) >= 10:  # 10 mensagens em 10 segundos
            try:
                await message.channel.send(
                    f"{message.author.mention} 🚨 **Detectado flood de mensagens!** Diminua a velocidade.",
                    delete_after=5
                )
            except:
                pass
        
        # Quarentena apenas em casos extremos
        if len(mensagens_no_canal) >= 15:  # 15 mensagens em 10 segundos
            await self.colocar_quarentena(message.author, 2, "Flood extremo de mensagens")
        
        return False
    
    async def monitorar_uso_bot(self):
        """Monitora o uso do próprio bot para detectar token comprometido"""
        await self.bot.wait_until_ready()
        
        while not self.bot.is_closed():
            try:
                agora = datetime.now()
                
                # Limpar contador antigo
                self.contador_acoes_bot = {
                    k: v for k, v in self.contador_acoes_bot.items()
                    if (agora - datetime.fromisoformat(v['timestamp'])).total_seconds() <= 60
                }
                
                # Verificar uso anômalo
                for guild_id, dados in self.contador_acoes_bot.items():
                    if dados['ban_count'] >= 50 or dados['channel_delete_count'] >= 50:
                        logger.critical(f"🚨 ALERTA CRÍTICO: Uso anômalo detectado no servidor {guild_id}")
                        await self.ativar_autodestruicao()
                        return
                
                await asyncio.sleep(30)
                
            except Exception as e:
                logger.error(f"Erro no monitoramento do bot: {e}")
                await asyncio.sleep(30)
    
    async def registrar_acao_bot(self, guild_id: int, acao: str):
        """Registra ação realizada pelo bot"""
        guild_id_str = str(guild_id)
        
        if guild_id_str not in self.contador_acoes_bot:
            self.contador_acoes_bot[guild_id_str] = {
                'ban_count': 0,
                'channel_delete_count': 0,
                'timestamp': datetime.now().isoformat()
            }
        
        if acao == 'ban':
            self.contador_acoes_bot[guild_id_str]['ban_count'] += 1
        elif acao == 'channel_delete':
            self.contador_acoes_bot[guild_id_str]['channel_delete_count'] += 1
    
    async def ativar_autodestruicao(self):
        """Ativa a autodestruição do token (proteção máxima)"""
        if self.auto_destruicao_ativa:
            return
        
        self.auto_destruicao_ativa = True
        logger.critical("💀 ATIVAÇÃO DE AUTODESTRUIÇÃO - Token comprometido detectado!")
        
        # Enviar alerta para todos os servidores
        for guild in self.bot.guilds:
            try:
                from events.member_events import get_log_channel
                canal_system = await get_log_channel(guild, "moderacao")
                
                if canal_system:
                    embed = discord.Embed(
                        title="💀 AUTODESTRUIÇÃO ATIVADA",
                        description="**Token do bot comprometido detectado!**\n\nO bot está se autodestruindo para proteger o servidor.",
                        color=0xff0000,
                        timestamp=datetime.now()
                    )
                    await canal_system.send(embed=embed)
            except:
                pass
        
        # Desligar o bot
        await self.bot.close()
    
    def adicionar_bot_whitelist(self, bot_id: int, autor: discord.Member) -> bool:
        """Adiciona bot à whitelist"""
        self.whitelist_bots.add(bot_id)
        self.salvar_dados_seguranca()
        
        logger.info(f"🔧 BOT WHITELIST: {autor.name} adicionou bot {bot_id} à whitelist")
        return True
    
    def remover_bot_whitelist(self, bot_id: int, autor: discord.Member) -> bool:
        """Remove bot da whitelist"""
        if bot_id in self.whitelist_bots:
            self.whitelist_bots.remove(bot_id)
            self.salvar_dados_seguranca()
            
            logger.info(f"🔧 BOT WHITELIST: {autor.name} removeu bot {bot_id} da whitelist")
            return True
        return False
    
    def obter_token_whitelist(self) -> Optional[str]:
        """Retorna o token atual para whitelist"""
        return self.whitelist_token
    
    def gerar_novo_token_whitelist(self) -> str:
        """Gera novo token para whitelist"""
        chars = string.ascii_letters + string.digits
        self.whitelist_token = ''.join(random.choice(chars) for _ in range(32))
        db.add_whitelist_token(self.whitelist_token)
        return self.whitelist_token
    
    def verificar_token_whitelist(self, token: str) -> bool:
        """Verifica se o token é válido"""
        return token == self.whitelist_token
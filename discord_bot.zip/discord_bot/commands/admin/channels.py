"""
COMANDOS DE GERENCIAMENTO DE CANAIS
Criação, exclusão, organização e configuração de canais
"""

import discord
from discord.ext import commands
import asyncio
from typing import Optional, List

from core.config import config
from core.database import db
from core.logger import logger

class ChannelCommands(commands.Cog):
    """Comandos completos para gerenciamento de canais"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command(name='d')
    @commands.has_permissions(manage_channels=True)
    async def deletar_canal(self, ctx, canal: discord.TextChannel = None):
        """🗑️ Deleta um canal específico"""
        canal = canal or ctx.channel
        try:
            nome_canal = canal.name
            await canal.delete()
            
            # Registrar ação do bot para segurança
            security_system = self.bot.systems.get('security')
            if security_system:
                await security_system.registrar_acao_bot(ctx.guild.id, 'channel_delete')
            
            embed = discord.Embed(
                title="🗑️ CANAL DELETADO",
                description=f"Canal `{nome_canal}` foi deletado com sucesso!",
                color=0x00ff00
            )
            await ctx.send(embed=embed, delete_after=10)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao deletar canal: {e}")
    
    @commands.command(name='-d')
    @commands.has_permissions(manage_channels=True)
    async def deletar_categoria(self, ctx, categoria_id: int):
        """🗑️ Deleta uma categoria e todos os seus canais"""
        try:
            categoria = ctx.guild.get_channel(categoria_id)
            if not categoria or not isinstance(categoria, discord.CategoryChannel):
                await ctx.send("❌ Categoria não encontrada!")
                return
            
            nome_categoria = categoria.name
            canais_na_categoria = len(categoria.channels)
            
            # Deletar todos os canais da categoria primeiro
            for canal in categoria.channels:
                try:
                    await canal.delete()
                    await asyncio.sleep(0.5)
                except Exception as e:
                    logger.error(f"Erro ao deletar canal {canal.name}: {e}")
            
            # Deletar a categoria
            await categoria.delete()
            
            # Registrar ação do bot para segurança
            security_system = self.bot.systems.get('security')
            if security_system:
                await security_system.registrar_acao_bot(ctx.guild.id, 'channel_delete')
            
            embed = discord.Embed(
                title="🗑️ CATEGORIA DELETADA",
                description=f"Categoria **{nome_categoria}** e seus **{canais_na_categoria}** canais foram deletados!",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao deletar categoria: {e}")
    
    @commands.command(name='ca')
    @commands.has_permissions(manage_channels=True)
    async def criar_canal_categoria(self, ctx, nome_canal: str, permissao: str, categoria_id: int):
        """💬 Cria canal em categoria específica"""
        try:
            categoria = ctx.guild.get_channel(categoria_id)
            if not categoria or not isinstance(categoria, discord.CategoryChannel):
                await ctx.send("❌ Categoria não encontrada!")
                return
            
            # Criar canal na categoria
            canal = await ctx.guild.create_text_channel(
                name=nome_canal.lower(),
                category=categoria
            )
            
            # Configurar permissões
            if permissao.lower() == "lock":
                await canal.set_permissions(ctx.guild.default_role, read_messages=False)
            elif permissao.lower() == "unlock":
                await canal.set_permissions(ctx.guild.default_role, read_messages=True)
            
            embed = discord.Embed(
                title="💬 CANAL CRIADO",
                description=f"Canal **{canal.name}** criado em **{categoria.name}**!",
                color=0x00ff00
            )
            embed.add_field(name="🔒 Permissão", value="Bloqueado" if permissao.lower() == "lock" else "Liberado", inline=True)
            embed.add_field(name="📁 Categoria", value=categoria.name, inline=True)
            embed.add_field(name="🆔 ID da Categoria", value=categoria_id, inline=True)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao criar canal: {e}")
    
    @commands.command(name='+ca')
    @commands.has_permissions(manage_channels=True)
    async def criar_categoria_canais(self, ctx, *args):
        """🏗️ Cria categoria e múltiplos canais"""
        if len(args) < 3 or len(args) % 2 == 0:
            embed = discord.Embed(
                title="❌ USO INCORRETO",
                description="**Como usar:** `!+ca <nome_canal1> <permissao1> <nome_canal2> <permissao2> ... <nome_categoria>`\n\n**Exemplo:** `!+ca chat unlock midia unlock resenhas unlock Minha Categoria`",
                color=0xff0000
            )
            await ctx.send(embed=embed)
            return
        
        # Último argumento é o nome da categoria
        nome_categoria = args[-1]
        canais_config = args[:-1]
        
        try:
            # Criar categoria
            categoria = await ctx.guild.create_category(nome_categoria.upper())
            
            # Criar canais na categoria
            canais_criados = []
            for i in range(0, len(canais_config), 2):
                nome_canal = canais_config[i].lower()
                permissao = canais_config[i+1].lower()
                
                canal = await ctx.guild.create_text_channel(
                    name=nome_canal,
                    category=categoria
                )
                
                # Configurar permissões
                if permissao == "lock":
                    await canal.set_permissions(ctx.guild.default_role, read_messages=False)
                elif permissao == "unlock":
                    await canal.set_permissions(ctx.guild.default_role, read_messages=True)
                
                canais_criados.append(f"• {canal.name} ({permissao})")
                await asyncio.sleep(0.5)
            
            embed = discord.Embed(
                title="🏗️ CATEGORIA E CANAIS CRIADOS",
                description=f"Categoria **{categoria.name}** criada com **{len(canais_criados)}** canais!",
                color=0x00ff00
            )
            embed.add_field(name="📂 Categoria", value=categoria.name, inline=True)
            embed.add_field(name="🆔 ID", value=categoria.id, inline=True)
            embed.add_field(name="🔢 Total de Canais", value=len(canais_criados), inline=True)
            embed.add_field(name="📋 Canais Criados", value="\n".join(canais_criados), inline=False)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao criar categoria e canais: {e}")
    
    @commands.command(name='x')
    @commands.has_permissions(manage_channels=True)
    async def modo_visualizacao(self, ctx, canal: discord.TextChannel = None):
        """👀 Ativa modo somente visualização no canal"""
        canal = canal or ctx.channel
        try:
            # Salvar permissões originais
            overwrites = canal.overwrites_for(ctx.guild.default_role)
            
            # Configurar somente visualização
            overwrites.send_messages = False
            overwrites.read_messages = True
            overwrites.add_reactions = False
            overwrites.use_application_commands = False
            overwrites.create_public_threads = False
            overwrites.create_private_threads = False
            overwrites.send_messages_in_threads = False
            
            await canal.set_permissions(ctx.guild.default_role, overwrite=overwrites)
            
            embed = discord.Embed(
                title="👀 MODO VISUALIZAÇÃO ATIVADO",
                description=f"{canal.mention} agora está em modo somente visualização",
                color=0xffff00
            )
            embed.add_field(name="📝 Permissões", value="✅ Ver mensagens\n❌ Enviar mensagens\n❌ Reagir\n❌ Usar comandos\n❌ Criar threads", inline=True)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao ativar modo visualização: {e}")
    
    @commands.command(name='-x')
    @commands.has_permissions(manage_channels=True)
    async def remover_visualizacao(self, ctx, canal: discord.TextChannel = None):
        """💬 Remove modo somente visualização do canal"""
        canal = canal or ctx.channel
        try:
            # Restaurar permissões de envio (None = herdar da categoria)
            overwrites = canal.overwrites_for(ctx.guild.default_role)
            overwrites.send_messages = None
            overwrites.add_reactions = None
            overwrites.use_application_commands = None
            overwrites.create_public_threads = None
            overwrites.create_private_threads = None
            overwrites.send_messages_in_threads = None
            
            await canal.set_permissions(ctx.guild.default_role, overwrite=overwrites)
            
            embed = discord.Embed(
                title="💬 MODO VISUALIZAÇÃO REMOVIDO",
                description=f"{canal.mention} agora permite envio de mensagens normalmente",
                color=0x00ff00
            )
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao remover modo visualização: {e}")
    
    @commands.command(name='lk')
    @commands.has_permissions(manage_channels=True)
    async def bloquear_canal(self, ctx, canal: discord.TextChannel = None):
        """🔒 Bloqueia um canal"""
        canal = canal or ctx.channel
        try:
            await canal.set_permissions(ctx.guild.default_role, read_messages=False)
            
            embed = discord.Embed(
                title="🔒 CANAL BLOQUEADO",
                description=f"{canal.mention} foi bloqueado",
                color=0xff0000
            )
            await ctx.send(embed=embed)
        except Exception as e:
            await ctx.send(f"❌ Erro ao bloquear canal: {e}")
    
    @commands.command(name='ulk')
    @commands.has_permissions(manage_channels=True)
    async def desbloquear_canal(self, ctx, canal: discord.TextChannel = None):
        """🔓 Desbloqueia um canal"""
        canal = canal or ctx.channel
        try:
            await canal.set_permissions(ctx.guild.default_role, read_messages=True)
            
            embed = discord.Embed(
                title="🔓 CANAL DESBLOQUEADO",
                description=f"{canal.mention} foi desbloqueado",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        except Exception as e:
            await ctx.send(f"❌ Erro ao desbloquear canal: {e}")
    
    @commands.command(name='mv')
    @commands.has_permissions(manage_channels=True)
    async def mover_canal(self, ctx, posicao_atual: int, nova_posicao: int):
        """📦 Move canal para nova posição"""
        try:
            canais = [canal for canal in ctx.guild.text_channels if canal.category]
            canais.sort(key=lambda x: x.position)
            
            if posicao_atual < 1 or posicao_atual > len(canais) or nova_posicao < 1 or nova_posicao > len(canais):
                await ctx.send(f"❌ Posições devem ser entre 1 e {len(canais)}")
                return
            
            canal = canais[posicao_atual - 1]
            await canal.edit(position=nova_posicao - 1)
            
            embed = discord.Embed(
                title="📦 CANAL MOVIDO",
                description=f"**{canal.name}** movido para posição **#{nova_posicao}**",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        except Exception as e:
            await ctx.send(f"❌ Erro ao mover canal: {e}")
    
    @commands.command(name='mv_cat')
    @commands.has_permissions(manage_channels=True)
    async def mover_categoria(self, ctx, posicao_atual: int, nova_posicao: int):
        """🏗️ Move categoria para nova posição"""
        try:
            categorias = [categoria for categoria in ctx.guild.categories if categoria.name]
            categorias.sort(key=lambda x: x.position)
            
            if posicao_atual < 1 or posicao_atual > len(categorias) or nova_posicao < 1 or nova_posicao > len(categorias):
                await ctx.send(f"❌ Posições devem ser entre 1 e {len(categorias)}")
                return
            
            categoria = categorias[posicao_atual - 1]
            await categoria.edit(position=nova_posicao - 1)
            
            embed = discord.Embed(
                title="🏗️ CATEGORIA MOVIDA",
                description=f"**{categoria.name}** movida para posição **#{nova_posicao}**",
                color=0x00ff00
            )
            await ctx.send(embed=embed)
        except Exception as e:
            await ctx.send(f"❌ Erro ao mover categoria: {e}")
    
    @commands.command(name='si')
    async def mostrar_simbolos(self, ctx):
        """🔍 Mostra símbolos atuais nos canais (ANÁLISE CIRÚRGICA)"""
        await ctx.typing()
        
        try:
            simbolos_analisados = {}
            
            for channel in ctx.guild.channels:
                if isinstance(channel, (discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel)):
                    nome = channel.name
                    
                    # Análise cirúrgica de símbolos por POSIÇÃO
                    partes = nome.split('・')
                    if len(partes) > 1:
                        simbolo = partes[0]  # Primeiro símbolo
                        posicao = 1
                        
                        if simbolo not in simbolos_analisados:
                            simbolos_analisados[simbolo] = {
                                'posicao': posicao,
                                'canais': [],
                                'tipo': channel.type.name
                            }
                        
                        simbolos_analisados[simbolo]['canais'].append(channel.name)
                    
                    # Buscar símbolos em outras posições
                    for i, parte in enumerate(partes):
                        if any(char in parte for char in '‧⁺┃▏▕│┊┋╰╯╭╮⊱⊰'):
                            if parte not in simbolos_analisados:
                                simbolos_analisados[parte] = {
                                    'posicao': i + 1,
                                    'canais': [channel.name],
                                    'tipo': channel.type.name
                                }
                            else:
                                simbolos_analisados[parte]['canais'].append(channel.name)
            
            if not simbolos_analisados:
                await ctx.send("❌ Nenhum símbolo encontrado nos canais")
                return
            
            embed = discord.Embed(
                title="🔍 ANÁLISE DE SÍMBOLOS NOS CANAIS",
                description="**Símbolos encontrados e suas posições:**",
                color=0x0099ff
            )
            
            for simbolo, dados in sorted(simbolos_analisados.items(), key=lambda x: x[1]['posicao']):
                canais_exemplo = dados['canais'][:3]
                info_canais = "\n".join([f"• {nome}" for nome in canais_exemplo])
                if len(dados['canais']) > 3:
                    info_canais += f"\n• ... e mais {len(dados['canais']) - 3} canais"
                
                embed.add_field(
                    name=f"`{simbolo}` - Posição {dados['posicao']}",
                    value=f"**Tipo:** {dados['tipo']}\n**Canais:**\n{info_canais}",
                    inline=False
                )
            
            embed.add_field(
                name="🎯 COMO USAR O COMANDO !w",
                value="**Exemplo:** `!w 1 🔧` - Substitui o símbolo da POSIÇÃO 1 por 🔧\n**Exemplo:** `!w 2 ⚡` - Substitui o símbolo da POSIÇÃO 2 por ⚡",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro na análise: {e}")
    
    @commands.command(name='w')
    @commands.has_permissions(manage_channels=True)
    async def substituir_simbolos_canais(self, ctx, posicao: int, novo_simbolo: str):
        """🔠 Substitui símbolos CIRURGICAMENTE por posição"""
        await ctx.typing()
        
        try:
            if posicao <= 0:
                await ctx.send("❌ A posição deve ser maior que 0")
                return
            
            canais_alterados = 0
            erros = 0
            
            for channel in ctx.guild.channels:
                if isinstance(channel, (discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel)):
                    nome_original = channel.name
                    
                    try:
                        # Substituição CIRÚRGICA por posição
                        partes = nome_original.split('・')
                        
                        if len(partes) >= posicao:
                            # Substituir apenas o símbolo na posição especificada
                            partes[posicao - 1] = novo_simbolo
                            novo_nome = '・'.join(partes)
                            
                            if novo_nome != nome_original:
                                await channel.edit(name=novo_nome)
                                canais_alterados += 1
                                await asyncio.sleep(0.5)  # Rate limit
                        
                    except Exception as e:
                        logger.error(f"Erro ao renomear {nome_original}: {e}")
                        erros += 1
            
            embed = discord.Embed(
                title="✅ SÍMBOLOS SUBSTITUÍDOS CIRURGICAMENTE",
                description=f"**{canais_alterados}** canais foram atualizados\n"
                           f"**Posição:** {posicao}\n"
                           f"**Novo símbolo:** {novo_simbolo}",
                color=0x00ff00
            )
            
            if erros > 0:
                embed.add_field(name="⚠️ Erros", value=f"{erros} canais não puderam ser alterados", inline=True)
            
            await ctx.send(embed=embed)
            
        except Exception as e:
            await ctx.send(f"❌ Erro ao substituir símbolos: {e}")
    
    @commands.command(name='ws')
    @commands.has_permissions(manage_channels=True)
    async def substituir_simbolo_especifico(self, ctx, simbolo_antigo: str, novo_simbolo: str):
        """🔧 Substitui símbolo específico (modo tradicional)"""
        await ctx.typing()
        
        try:
            canais_alterados = 0
            
            for channel in ctx.guild.channels:
                if isinstance(channel, (discord.TextChannel, discord.VoiceChannel, discord.CategoryChannel)):
                    nome_original = channel.name
                    
                    # Substituição exata do símbolo
                    if simbolo_antigo in nome_original:
                        novo_nome = nome_original.replace(simbolo_antigo, novo_simbolo)
                        
                        if novo_nome != nome_original:
                            try:
                                await channel.edit(name=novo_nome)
  
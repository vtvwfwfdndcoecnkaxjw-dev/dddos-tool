#!/usr/bin/env python3
"""
MAIN ENTRY POINT - BOT DISCORD AVANÇADO
Sistema completo com +100 funcionalidades
"""

import asyncio
import traceback
import sys
import os

# Adicionar o diretório atual ao path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.bot import AdvancedBot

async def main():
    """Função principal de inicialização"""
    print("=" * 60)
    print("🚀 INICIALIZANDO BOT DISCORD AVANÇADO")
    print("=" * 60)
    
    try:
        # Inicializar bot
        bot = AdvancedBot()
        
        # Carregar extensões
        await bot.load_extensions()
        
        # Iniciar bot
        print("✅ Sistema carregado com sucesso!")
        print("📊 Extensões carregadas:", len(bot.extensions))
        print("=" * 60)
        
        await bot.start_bot()
        
    except KeyboardInterrupt:
        print("\n🛑 Bot interrompido pelo usuário")
    except Exception as e:
        print(f"❌ ERRO CRÍTICO: {e}")
        traceback.print_exc()
    finally:
        print("\n🔴 Bot finalizado")

if __name__ == "__main__":
    # Configurar loop de eventos
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Até mais!")
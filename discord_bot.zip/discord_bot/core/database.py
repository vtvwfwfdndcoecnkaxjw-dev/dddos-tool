"""
SISTEMA DE BANCO DE DADOS
Gerencia todos os dados do bot com JSON
"""

import json
import os
from typing import Dict, Any, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class Database:
    """Sistema de banco de dados baseado em JSON"""
    
    def __init__(self, data_file: str = 'data/data.json'):
        self.data_file = data_file
        self.data = self._load_default_data()
        self._ensure_data_dir()
        self.load()
    
    def _ensure_data_dir(self) -> None:
        """Garante que o diretório de dados existe"""
        data_dir = os.path.dirname(self.data_file)
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
    
    def _load_default_data(self) -> Dict[str, Any]:
        """Carrega estrutura de dados padrão"""
        return {
            'advertencias': {},
            'convites': {},
            'config': {},
            'contadores': {},
            'historico_ia': {},
            'pontuacao': {},
            'config_canais': {},
            'lembretes_anuncios': {},
            'missoes_cyber': {},
            'conversas_ativas': {},
            'rate_limit_data': {},
            'comandos_personalizados': {},
            'whitelist_tokens': {},
            'backups_emergencia': {},
            'user_profiles': {},
            'economy': {},
            'shop_items': {},
            'active_missions': {},
            'tickets': {},
            'quarentena': {}
        }
    
    def load(self) -> None:
        """Carrega dados do arquivo JSON"""
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    loaded_data = json.load(f)
                    # Atualizar apenas as chaves existentes
                    for key in self.data.keys():
                        if key in loaded_data:
                            self.data[key] = loaded_data[key]
                logger.info(f"✅ Dados carregados de {self.data_file}")
            else:
                logger.info("📁 Arquivo de dados não encontrado, criando novo...")
                self.save()
        except Exception as e:
            logger.error(f"❌ Erro ao carregar dados: {e}")
            self.data = self._load_default_data()
    
    def save(self) -> None:
        """Salva dados no arquivo JSON"""
        try:
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
            logger.debug(f"💾 Dados salvos em {self.data_file}")
        except Exception as e:
            logger.error(f"❌ Erro ao salvar dados: {e}")
    
    # ========== MÉTODOS PARA ADVERTÊNCIAS ==========
    def add_warning(self, user_id: int, moderator_id: int, reason: str) -> int:
        """Adiciona advertência a um usuário"""
        user_id_str = str(user_id)
        
        if user_id_str not in self.data['advertencias']:
            self.data['advertencias'][user_id_str] = []
        
        warning_data = {
            "moderador": moderator_id,
            "motivo": reason,
            "data": datetime.now().isoformat(),
            "id": len(self.data['advertencias'][user_id_str]) + 1
        }
        
        self.data['advertencias'][user_id_str].append(warning_data)
        self.save()
        
        return len(self.data['advertencias'][user_id_str])
    
    def get_warnings(self, user_id: int) -> list:
        """Obtém advertências de um usuário"""
        user_id_str = str(user_id)
        return self.data['advertencias'].get(user_id_str, [])
    
    def remove_warning(self, user_id: int, warning_index: int = -1) -> bool:
        """Remove advertência de um usuário"""
        user_id_str = str(user_id)
        
        if user_id_str not in self.data['advertencias']:
            return False
        
        warnings = self.data['advertencias'][user_id_str]
        
        if not warnings:
            return False
        
        if warning_index == -1:
            # Remove a última
            warnings.pop()
        elif 0 <= warning_index < len(warnings):
            warnings.pop(warning_index)
        else:
            return False
        
        self.save()
        return True
    
    # ========== MÉTODOS PARA PONTUAÇÃO ==========
    def add_points(self, user_id: int, points: int, reason: str) -> int:
        """Adiciona pontos a um usuário"""
        user_id_str = str(user_id)
        
        if user_id_str not in self.data['pontuacao']:
            self.data['pontuacao'][user_id_str] = {
                "pontos": 0,
                "historico": []
            }
        
        self.data['pontuacao'][user_id_str]["pontos"] += points
        self.data['pontuacao'][user_id_str]["historico"].append({
            "data": datetime.now().isoformat(),
            "motivo": reason,
            "pontos": points
        })
        
        self.save()
        return self.data['pontuacao'][user_id_str]["pontos"]
    
    def get_points(self, user_id: int) -> int:
        """Obtém pontos de um usuário"""
        user_id_str = str(user_id)
        if user_id_str in self.data['pontuacao']:
            return self.data['pontuacao'][user_id_str]["pontos"]
        return 0
    
    # ========== MÉTODOS PARA CONVITES ==========
    def add_invite(self, inviter_id: int, invited_id: int) -> bool:
        """Registra um convite"""
        inviter_id_str = str(inviter_id)
        
        if inviter_id_str not in self.data['convites']:
            self.data['convites'][inviter_id_str] = {
                "convidados": [],
                "total": 0
            }
        
        invited_id_str = str(invited_id)
        
        if invited_id_str not in self.data['convites'][inviter_id_str]["convidados"]:
            self.data['convites'][inviter_id_str]["convidados"].append(invited_id_str)
            self.data['convites'][inviter_id_str]["total"] += 1
            self.save()
            return True
        
        return False
    
    def get_invite_count(self, user_id: int) -> int:
        """Obtém contagem de convites de um usuário"""
        user_id_str = str(user_id)
        if user_id_str in self.data['convites']:
            return self.data['convites'][user_id_str]["total"]
        return 0
    
    # ========== MÉTODOS PARA CONFIGURAÇÕES ==========
    def set_channel_config(self, channel_type: str, channel_id: int) -> None:
        """Configura um canal para um tipo específico"""
        if 'config_canais' not in self.data:
            self.data['config_canais'] = {}
        
        if 'canais_automaticos' not in self.data['config_canais']:
            self.data['config_canais']['canais_automaticos'] = {}
        
        self.data['config_canais']['canais_automaticos'][channel_type] = channel_id
        self.save()
    
    def get_channel_config(self, channel_type: str) -> Optional[int]:
        """Obtém configuração de canal"""
        if ('config_canais' in self.data and 
            'canais_automaticos' in self.data['config_canais'] and
            channel_type in self.data['config_canais']['canais_automaticos']):
            return self.data['config_canais']['canais_automaticos'][channel_type]
        return None
    
    # ========== MÉTODOS PARA TICKETS ==========
    def create_ticket(self, ticket_id: int, user_id: int, channel_id: int) -> None:
        """Cria um novo ticket"""
        if 'tickets' not in self.data:
            self.data['tickets'] = {}
        
        self.data['tickets'][str(ticket_id)] = {
            "user_id": user_id,
            "channel_id": channel_id,
            "created_at": datetime.now().isoformat(),
            "status": "open"
        }
        self.save()
    
    def close_ticket(self, ticket_id: int) -> bool:
        """Fecha um ticket"""
        ticket_id_str = str(ticket_id)
        
        if 'tickets' in self.data and ticket_id_str in self.data['tickets']:
            self.data['tickets'][ticket_id_str]["status"] = "closed"
            self.data['tickets'][ticket_id_str]["closed_at"] = datetime.now().isoformat()
            self.save()
            return True
        
        return False
    
    # ========== MÉTODOS PARA IA ==========
    def add_ai_history(self, user_id: int, role: str, content: str) -> None:
        """Adiciona mensagem ao histórico da IA"""
        user_id_str = str(user_id)
        
        if user_id_str not in self.data['historico_ia']:
            self.data['historico_ia'][user_id_str] = []
        
        self.data['historico_ia'][user_id_str].append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
        
        # Limitar histórico a 10 mensagens
        if len(self.data['historico_ia'][user_id_str]) > 10:
            self.data['historico_ia'][user_id_str] = self.data['historico_ia'][user_id_str][-10:]
        
        self.save()
    
    def get_ai_history(self, user_id: int) -> list:
        """Obtém histórico da IA de um usuário"""
        user_id_str = str(user_id)
        return self.data['historico_ia'].get(user_id_str, [])
    
    def clear_ai_history(self, user_id: int) -> None:
        """Limpa histórico da IA de um usuário"""
        user_id_str = str(user_id)
        if user_id_str in self.data['historico_ia']:
            self.data['historico_ia'][user_id_str] = []
            self.save()
    
    # ========== MÉTODOS PARA WHITELIST ==========
    def add_whitelist_token(self, token: str) -> None:
        """Adiciona token de whitelist"""
        if 'whitelist_tokens' not in self.data:
            self.data['whitelist_tokens'] = {}
        
        self.data['whitelist_tokens']['master_token'] = token
        self.save()
    
    def get_whitelist_token(self) -> Optional[str]:
        """Obtém token de whitelist"""
        if ('whitelist_tokens' in self.data and 
            'master_token' in self.data['whitelist_tokens']):
            return self.data['whitelist_tokens']['master_token']
        return None
    
    # ========== MÉTODOS PARA BACKUP ==========
    def create_backup(self, backup_id: str, backup_data: dict) -> None:
        """Cria backup de emergência"""
        if 'backups_emergencia' not in self.data:
            self.data['backups_emergencia'] = {}
        
        self.data['backups_emergencia'][backup_id] = backup_data
        self.save()
    
    def get_backup(self, backup_id: str) -> Optional[dict]:
        """Obtém backup"""
        if ('backups_emergencia' in self.data and 
            backup_id in self.data['backups_emergencia']):
            return self.data['backups_emergencia'][backup_id]
        return None
    
    # ========== MÉTODOS PARA COMANDOS PERSONALIZADOS ==========
    def add_custom_command(self, command_name: str, command_type: str, config: str, creator_id: int) -> None:
        """Adiciona comando personalizado"""
        if 'comandos_personalizados' not in self.data:
            self.data['comandos_personalizados'] = {}
        
        self.data['comandos_personalizados'][command_name] = {
            'tipo': command_type,
            'configuracao': config,
            'criador': creator_id,
            'criado_em': datetime.now().isoformat()
        }
        self.save()
    
    def get_custom_command(self, command_name: str) -> Optional[dict]:
        """Obtém comando personalizado"""
        if ('comandos_personalizados' in self.data and 
            command_name in self.data['comandos_personalizados']):
            return self.data['comandos_personalizados'][command_name]
        return None
    
    def remove_custom_command(self, command_name: str) -> bool:
        """Remove comando personalizado"""
        if ('comandos_personalizados' in self.data and 
            command_name in self.data['comandos_personalizados']):
            del self.data['comandos_personalizados'][command_name]
            self.save()
            return True
        return False
    
    # ========== MÉTODOS PARA QUARENTENA ==========
    def add_quarantine(self, user_id: int, end_time: str, reason: str, previous_roles: list) -> None:
        """Adiciona usuário à quarentena"""
        user_id_str = str(user_id)
        
        if 'quarentena' not in self.data:
            self.data['quarentena'] = {}
        
        self.data['quarentena'][user_id_str] = {
            "tempo_fim": end_time,
            "motivo": reason,
            "cargos_anteriores": previous_roles
        }
        self.save()
    
    def remove_quarantine(self, user_id: int) -> bool:
        """Remove usuário da quarentena"""
        user_id_str = str(user_id)
        
        if 'quarentena' in self.data and user_id_str in self.data['quarentena']:
            del self.data['quarentena'][user_id_str]
            self.save()
            return True
        
        return False
    
    def get_quarantine(self, user_id: int) -> Optional[dict]:
        """Obtém dados da quarentena de um usuário"""
        user_id_str = str(user_id)
        if 'quarentena' in self.data and user_id_str in self.data['quarentena']:
            return self.data['quarentena'][user_id_str]
        return None
    
    # ========== MÉTODOS PARA PERFIS ==========
    def get_user_profile(self, user_id: int) -> dict:
        """Obtém ou cria perfil de usuário"""
        user_id_str = str(user_id)
        
        if 'user_profiles' not in self.data:
            self.data['user_profiles'] = {}
        
        if user_id_str not in self.data['user_profiles']:
            self.data['user_profiles'][user_id_str] = {
                "created_at": datetime.now().isoformat(),
                "level": 1,
                "experience": 0,
                "achievements": [],
                "bio": "",
                "social_links": {},
                "customizations": {}
            }
            self.save()
        
        return self.data['user_profiles'][user_id_str]
    
    def update_user_profile(self, user_id: int, updates: dict) -> None:
        """Atualiza perfil de usuário"""
        user_id_str = str(user_id)
        
        if 'user_profiles' not in self.data:
            self.data['user_profiles'] = {}
        
        if user_id_str not in self.data['user_profiles']:
            self.get_user_profile(user_id)
        
        self.data['user_profiles'][user_id_str].update(updates)
        self.save()
    
    # ========== MÉTODOS PARA ECONOMIA ==========
    def get_economy_data(self, user_id: int) -> dict:
        """Obtém ou cria dados econômicos de um usuário"""
        user_id_str = str(user_id)
        
        if 'economy' not in self.data:
            self.data['economy'] = {}
        
        if user_id_str not in self.data['economy']:
            self.data['economy'][user_id_str] = {
                "coins": 1000,
                "bank": 0,
                "inventory": {},
                "transactions": [],
                "last_daily": None,
                "last_work": None
            }
            self.save()
        
        return self.data['economy'][user_id_str]
    
    def update_economy(self, user_id: int, updates: dict) -> None:
        """Atualiza dados econômicos de um usuário"""
        user_id_str = str(user_id)
        
        if 'economy' not in self.data:
            self.data['economy'] = {}
        
        if user_id_str not in self.data['economy']:
            self.get_economy_data(user_id)
        
        self.data['economy'][user_id_str].update(updates)
        self.save()
    
    # ========== MÉTODOS GERAIS ==========
    def get_all_data(self, key: str) -> dict:
        """Obtém todos os dados de uma chave específica"""
        return self.data.get(key, {})
    
    def update_data(self, key: str, value: Any) -> None:
        """Atualiza dados de uma chave específica"""
        self.data[key] = value
        self.save()
    
    def clear_data(self, key: str) -> None:
        """Limpa dados de uma chave específica"""
        if key in self.data:
            self.data[key] = {}
            self.save()

# Instância global do banco de dados
db = Database()